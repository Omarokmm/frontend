export const  Roles = {
    0: "admin",
    1: "manager",
    2: "teamleader",
    3: "technician",
    // Add more roles as needed
  };