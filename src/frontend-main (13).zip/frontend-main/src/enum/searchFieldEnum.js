// Define the search fields "enum"
const SEARCH_FIELDS = Object.freeze({
    CASE_NUMBER: 'caseNumber',
    DOCTOR: 'doctor',
    PATIENT: 'patient'
  });
  
  export default SEARCH_FIELDS;