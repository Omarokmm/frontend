import { useEffect, useState } from "react";
import * as _global from "../../config/global";

const Home = ()=> {
    return (
        <div>Dashboard</div>
    );
}

export default Home;